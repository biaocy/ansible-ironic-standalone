# TODO(bill.chan) license

from ironic.common.i18n import _
from ironic.drivers import base
from ironic.drivers.modules.ibmc import utils


class IBMCVendor(base.VendorInterface):

    def __init__(self):
        """Initialize the iBMC vendor interface."""
        super(IBMCVendor, self).__init__()

    def validate(self, task, method=None, **kwargs):
        """Validate vendor-specific actions.

        If invalid, raises an exception; otherwise returns None.

        :param task: A task from TaskManager.
        :param method: Method to be validated
        :param kwargs: Info for action.
        :raises: UnsupportedDriverExtension if 'method' can not be mapped to
                 the supported interfaces.
        :raises: InvalidParameterValue if kwargs does not contain 'method'.
        :raises: MissingParameterValue
        """
        utils.parse_driver_info(task.node)

    def get_properties(self):
        """Return the properties of the interface.

        :returns: dictionary of <property name>:<property description> entries.
        """
        return utils.COMMON_PROPERTIES.copy()

    @base.passthru(['GET'], async=False,
                   description=_('Returns a comma-separated string, '
                                 'which containing node boot types, '
                                 'in ascending order'))
    def list_boot_type_order(self, task, **kwargs):
        """List boot type order of the node.

        :param task: A TaskManager instance containing the node to act on.
        :param kwargs: Not used.
        :raises: InvalidParameterValue if kwargs does not contain 'method'.
        :raises: MissingParameterValue
        :returns: A comma-separated string, which containing node
                  boot types, in ascending order.
        """
        self.validate(task)
        system = utils.get_system(task.node)
        attrs = system.bios
        keys = [k for k in attrs.keys()
                if k.lower().startswith('boottypeorder')]
        boot_types = [attrs.get(t) for t in sorted(keys)]
        return ', '.join(boot_types)
