# TODO(bill.chan) license

import mock
from oslo_utils import importutils

from ironic.common import exception
from ironic.common import states
from ironic.conductor import task_manager
from ironic.drivers.modules.ibmc import power as ibmc_power
from ironic.drivers.modules.ibmc import utils as ibmc_utils
from ironic.tests.unit.db import base as db_base
from ironic.tests.unit.db import utils as db_utils
from ironic.tests.unit.objects import utils as obj_utils

sushy = importutils.try_import('sushy')

INFO_DICT = db_utils.get_test_ibmc_info()


@mock.patch('eventlet.greenthread.sleep', lambda _t: None)
class RedfishPowerTestCase(db_base.DbTestCase):

    def setUp(self):
        super(RedfishPowerTestCase, self).setUp()
        self.config(enabled_hardware_types=['ibmc'],
                    enabled_power_interfaces=['ibmc'],
                    enabled_management_interfaces=['ibmc'])
        self.node = obj_utils.create_test_node(
            self.context, driver='ibmc', driver_info=INFO_DICT)

    @mock.patch.object(ibmc_power, 'sushy', None)
    def test_loading_error(self):
        self.assertRaisesRegex(
            exception.DriverLoadError,
            'Unable to import the sushy library',
            ibmc_power.IBMCPower)

    def test_get_properties(self):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=True) as task:
            properties = task.driver.get_properties()
            for prop in ibmc_utils.COMMON_PROPERTIES:
                self.assertIn(prop, properties)

    @mock.patch.object(ibmc_utils, 'parse_driver_info', autospec=True)
    def test_validate(self, mock_parse_driver_info):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=True) as task:
            task.driver.power.validate(task)
            mock_parse_driver_info.assert_called_once_with(task.node)

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_get_power_state(self, mock_get_system):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=True) as task:
            expected_values = [
                (sushy.SYSTEM_POWER_STATE_ON, states.POWER_ON),
                (sushy.SYSTEM_POWER_STATE_POWERING_ON, states.POWER_ON),
                (sushy.SYSTEM_POWER_STATE_OFF, states.POWER_OFF),
                (sushy.SYSTEM_POWER_STATE_POWERING_OFF, states.POWER_OFF)
            ]
            for current, expected in expected_values:
                mock_get_system.return_value = mock.Mock(power_state=current)
                self.assertEqual(expected,
                                 task.driver.power.get_power_state(task))
                mock_get_system.assert_called_once_with(task.node)
                mock_get_system.reset_mock()

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_set_power_state(self, mock_get_system):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=False) as task:
            expected_values = [
                (states.POWER_ON, sushy.RESET_ON),
                (states.POWER_OFF, sushy.RESET_FORCE_OFF),
                (states.REBOOT, sushy.RESET_FORCE_RESTART),
                (states.SOFT_REBOOT, sushy.RESET_GRACEFUL_RESTART),
                (states.SOFT_POWER_OFF, sushy.RESET_GRACEFUL_SHUTDOWN)
            ]

            for target, expected in expected_values:
                if target in (states.POWER_OFF, states.SOFT_POWER_OFF):
                    final = sushy.SYSTEM_POWER_STATE_OFF
                    transient = sushy.SYSTEM_POWER_STATE_ON
                else:
                    final = sushy.SYSTEM_POWER_STATE_ON
                    transient = sushy.SYSTEM_POWER_STATE_OFF

                system_result = [
                    mock.Mock(power_state=transient)
                ] * 3 + [mock.Mock(power_state=final)]
                mock_get_system.side_effect = system_result

                task.driver.power.set_power_state(task, target)

                # Asserts
                system_result[0].reset_system.assert_called_once_with(expected)
                mock_get_system.assert_called_with(task.node)
                self.assertEqual(4, mock_get_system.call_count)

                # Reset mocks
                mock_get_system.reset_mock()

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_set_power_state_not_reached(self, mock_get_system):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=False) as task:
            self.config(power_state_change_timeout=2, group='conductor')
            expected_values = [
                (states.POWER_ON, sushy.RESET_ON),
                (states.POWER_OFF, sushy.RESET_FORCE_OFF),
                (states.REBOOT, sushy.RESET_FORCE_RESTART),
                (states.SOFT_REBOOT, sushy.RESET_GRACEFUL_RESTART),
                (states.SOFT_POWER_OFF, sushy.RESET_GRACEFUL_SHUTDOWN)
            ]

            for target, expected in expected_values:
                fake_system = mock_get_system.return_value
                if target in (states.POWER_OFF, states.SOFT_POWER_OFF):
                    fake_system.power_state = sushy.SYSTEM_POWER_STATE_ON
                else:
                    fake_system.power_state = sushy.SYSTEM_POWER_STATE_OFF

                self.assertRaises(exception.PowerStateFailure,
                                  task.driver.power.set_power_state,
                                  task, target)

                # Asserts
                fake_system.reset_system.assert_called_once_with(expected)
                mock_get_system.assert_called_with(task.node)

                # Reset mocks
                mock_get_system.reset_mock()

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_set_power_state_fail(self, mock_get_system):
        fake_system = mock_get_system.return_value
        fake_system.reset_system.side_effect = (
            sushy.exceptions.SushyError())

        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=False) as task:
            self.assertRaisesRegex(
                exception.RedfishError, 'IBMC set power state',
                task.driver.power.set_power_state, task, states.POWER_ON)
            fake_system.reset_system.assert_called_once_with(
                sushy.RESET_ON)
            mock_get_system.assert_called_once_with(task.node)

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_reboot(self, mock_get_system):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=False) as task:
            expected_values = [
                (sushy.SYSTEM_POWER_STATE_ON, sushy.RESET_FORCE_RESTART),
                (sushy.SYSTEM_POWER_STATE_OFF, sushy.RESET_ON)
            ]

            for current, expected in expected_values:
                system_result = [
                    # Initial state
                    mock.Mock(power_state=current),
                    # Transient state - powering off
                    mock.Mock(power_state=sushy.SYSTEM_POWER_STATE_OFF),
                    # Final state - down powering off
                    mock.Mock(power_state=sushy.SYSTEM_POWER_STATE_ON)
                ]
                mock_get_system.side_effect = system_result

                task.driver.power.reboot(task)

                # Asserts
                system_result[0].reset_system.assert_called_once_with(expected)
                mock_get_system.assert_called_with(task.node)
                self.assertEqual(3, mock_get_system.call_count)

                # Reset mocks
                mock_get_system.reset_mock()

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_reboot_not_reached(self, mock_get_system):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=False) as task:
            fake_system = mock_get_system.return_value
            fake_system.power_state = sushy.SYSTEM_POWER_STATE_OFF

            self.assertRaises(exception.PowerStateFailure,
                              task.driver.power.reboot, task)

            # Asserts
            fake_system.reset_system.assert_called_once_with(sushy.RESET_ON)
            mock_get_system.assert_called_with(task.node)

    @mock.patch.object(ibmc_utils, 'get_system', autospec=True)
    def test_reboot_fail(self, mock_get_system):
        fake_system = mock_get_system.return_value
        fake_system.reset_system.side_effect = (
            sushy.exceptions.SushyError())

        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=False) as task:
            fake_system.power_state = sushy.SYSTEM_POWER_STATE_ON
            self.assertRaisesRegex(
                exception.RedfishError, 'IBMC reboot failed',
                task.driver.power.reboot, task)
            fake_system.reset_system.assert_called_once_with(
                sushy.RESET_FORCE_RESTART)
            mock_get_system.assert_called_once_with(task.node)

    def test_get_supported_power_states(self):
        with task_manager.acquire(self.context, self.node.uuid,
                                  shared=True) as task:
            supported_power_states = (
                task.driver.power.get_supported_power_states(task))
            self.assertEqual(list(ibmc_power.SET_POWER_STATE_MAP),
                             supported_power_states)
